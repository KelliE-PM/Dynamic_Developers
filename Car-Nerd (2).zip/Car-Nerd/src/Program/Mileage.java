package Program;

//Import resources
import java.util.Scanner;
	
public class Mileage {
	
	// Data fields

	public static int startMileage = -1;
	public static int currentMileage = 0;
	public static int lastChangeMileage = 0;
	public static int nextChangeMileage = 0;
	
	public static String startDate = null;
	public static String lastChangeDate;
	public static String currentDate;
	
	public static boolean synthetic;
	public static boolean changeDue;
	
	public static void main(String[] args) {
		
	// Open resources
	Scanner scanner = new Scanner(System.in);		
			
	// Input mileage
	System.out.print("Enter your mileage: ");
	currentMileage = scanner.nextInt();
		
	System.out.print("Enter today's date(mm/dd/yy): ");
	currentDate = scanner.next();
	
	// First entry
	if (startMileage == -1) {startMileage = currentMileage;}
	if (startDate == null) {startDate = currentDate;}
	
	// Oil Change
	System.out.print("Enter your mileage at last oil change: ");
	lastChangeMileage = scanner.nextInt();
	
	System.out.print("Enter the date of service (mm/dd/yy): ");
	lastChangeDate = scanner.next();
	
	System.out.print("Did you use synthetic oil? (y/n): ");
	String oil = scanner.next();
	if (oil.equals("y")) {synthetic = true;
		nextChangeMileage = (lastChangeMileage + 5000);}
	
	if (oil.equals("n")) {synthetic = false; 
		nextChangeMileage = (lastChangeMileage + 3000);}
	
	// Reminder
	System.out.println("Your next oil change is due at mileage: "
		+ nextChangeMileage);
	
	if (currentMileage >= nextChangeMileage) {changeDue = true;
		System.out.print("You are due for an oil change");}
		

	// Close resources
	scanner.close();
	
	}
}	
	
	// mile = 1.609 km

	// oilChange(lastChangeMileage, lastChangeDate, synthetic)
	// newMileage(currentMileage, currentDate)
	// remindOilChange(changeDue)
