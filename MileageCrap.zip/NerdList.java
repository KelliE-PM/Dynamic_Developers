  
package CarNerd;

import java.util.ArrayList;

public class NerdList {
	static ArrayList<Car> listCars = new ArrayList<Car>();
	static ArrayList<Mileage> listMiles = new ArrayList<Mileage>();
	
	NerdList(){}
}